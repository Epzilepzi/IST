Colours for website:

Blue Background Colour #47A4D6
White Text Colour #FFFFFF
Active Link Colour (Blue) #46A1D5
In-Active Link Colour (Silver) #D6DADC
Content Text Colour (Silver) #8C969B
